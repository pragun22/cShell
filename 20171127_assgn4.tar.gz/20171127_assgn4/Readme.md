## Question 1 

- Players and referees come according to their probability as mentioned in question
- then the first two players are able to meet Organiser and then the organiser is blocked
- for other players and will wait till the referee comes for their match
- as soon as referee comes and he meets the organiser the trio enter the court
- players do warm up and referee adjust the quipment
- after all this game is started by referee and now the Organiser is free to meet with 
- other players and referees

# things used
- mutex
- cond
- threads
- semaphores

## Question 2

- enter numbre of booths and then enter number of evm and voters for each booth
- then each evm will be activated first
- and the first free evm will declare that its free with specifying its slots
- then voters will come one by one and evm will be assigned to them
- after all voters in a slot have arrived voting phase will begin
- after completion output of voting done at which evm of which booth will be given
- then again the same process will follow till all the voters are done in the booth

#things used
- mutex
- cond
- threads


no deadlocks in any code